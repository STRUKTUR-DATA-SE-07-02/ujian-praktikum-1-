#include <iostream>
#include "DoubleLinkedList.cpp"
#include "DoubleLinkedList.h"

int main() {
    List mahasiswalist = createNewList();

    Mahasiswa newMahasiswa;
    std::cout << "Masukkan nama mahasiswa: ";
    std::cin >> newMahasiswa.nama; 
    std::cout << "Masukkan NIM mahasiswa: ";
    std::cin >> newMahasiswa.nim; 
    std::cout << "Masukkan nilai assessment: ";
    std::cin >> newMahasiswa.assessment;
    std::cout << "Masukkan nilai pratikum: ";
    std::cin >> newMahasiswa.pratikum;

    Node* newNode = newElement(newMahasiswa);
    insertFirst(mahasiswalist, newNode);

    Node* topMahasiswa = findHighestAssessment(mahasiswalist);
    if (topMahasiswa != nullptr) {
        std::cout << "Nama Mahasiswa: " << topMahasiswa->data.nama << std::endl;
        std::cout << "NIM Mahasiswa: " << topMahasiswa->data.nim << std::endl;
    }

    printList(mahasiswalist);
    return 0;
}