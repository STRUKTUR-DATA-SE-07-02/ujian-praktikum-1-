#ifndef DOUBLE_LINKED_LIST_H
#define DOUBLE_LINKED_LIST_H
#include <string>
#include <iostream>
struct Mahasiswa {
    std::string nama;
    std::string nim;
    float assessment;
    float pratikum;
};

struct Node {
    Mahasiswa data;
    Node* prev;
    Node* next;
};

struct List {
    Node* head;
    Node* tail;
};

Node* newElement(Mahasiswa data);
List createNewList();
bool isEmpty(const List& a);
void insertFirst(List& a, Node* p);
void insertLast(List& a, Node* p);
void printList(const List& a);
Node* findHighestAssessment(const List& a);
void removeDuplicate(List& a);

#endif 