#include "DoubleLinkedList.h"
#include <iostream>

Node* newElement(Mahasiswa data) {
    Node* newNode = new Node;
    newNode->data = data;
    newNode->prev = nullptr;
    newNode->next = nullptr;
    return newNode;
}

List createNewList() {
    List a;
    a.head = nullptr;
    a.tail = nullptr;
    return a;
}

bool isEmpty(const List& a) {
    return (a.head == nullptr);
}

void insertFirst(List& a, Node* p) {
    if (isEmpty(a)) {
        a.head = p;
        a.tail = p;
    } else {
        p->next = a.head;
        a.head->prev = p;
        a.head = p;
    }
}

void insertLast(List& a, Node* p) {
    if (isEmpty(a)) {
        a.head = p;
        a.tail = p;
    } else {
        a.tail->next = p;
        p->prev = a.tail;
        a.tail = p;
    }
}

void printList(const List& a) {
    Node* current = a.head;
    while (current != nullptr) {
        std::cout << "Nama: " << current->data.nama 
                  << ", NIM: " << current->data.nim 
                  << ", Assessment: " << current->data.assessment 
                  << ", Pratikum: " << current->data.pratikum << std::endl;
        current = current->next;
    }
}

Node* findHighestAssessment(const List& a) {
    if (isEmpty(a)) return nullptr;
    Node* maxNode = a.head;
    Node* current = a.head->next;
    while (current != nullptr) {
        if (current->data.assessment > maxNode->data.assessment) {
            maxNode = current;
        }
        current = current->next;
    }
    return maxNode;
}

void removeDuplicate(List& a) {
    Node* current = a.head;
    while (current != nullptr) {
        Node* runner = current->next;
        while (runner != nullptr) {
            if (current->data.nim == runner->data.nim) {
                Node* temp = runner;
                if (runner->prev != nullptr) runner->prev->next = runner->next;
                if (runner->next != nullptr) runner->next->prev = runner->prev;
                if (runner == a.tail) a.tail = runner->prev;
                runner = runner->next;
                delete temp; 
            } else {
                runner = runner->next;
            }
        }
        current = current->next;
    }
}