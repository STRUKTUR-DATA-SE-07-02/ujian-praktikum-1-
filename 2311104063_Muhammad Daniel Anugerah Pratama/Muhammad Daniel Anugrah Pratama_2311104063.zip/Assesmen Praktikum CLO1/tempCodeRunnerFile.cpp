#include <iostream>
#include <string>
using namespace std;

struct Mahasiswa {
    string nama;
    int NIM;
    string kelas;
    float nilaiAsesmen;
    float nilaiPraktikum;
    Mahasiswa* next;
};

struct SingleList {
    Mahasiswa* first;
};

void newList(SingleList &L) {
    L.first = nullptr;
}

Mahasiswa* newElement(string nama, int NIM, string kelas, float nilaiAsesmen, float nilaiPraktikum) {
    Mahasiswa* p = new Mahasiswa;
    p->nama = nama;
    p->NIM = NIM;
    p->kelas = kelas;
    p->nilaiAsesmen = nilaiAsesmen;
    p->nilaiPraktikum = nilaiPraktikum;
    p->next = nullptr;
    return p;
}


void insertFirst(SingleList &L, Mahasiswa* p) {
    p->next = L.first;
    L.first = p;
}


void insertLast(SingleList &L, Mahasiswa* p) {
    if (L.first == nullptr) {
        L.first = p;
    } else {
        Mahasiswa* last = L.first;
        while (last->next != nullptr) {
            last = last->next;
        }
        last->next = p;
    }
}


void printList(SingleList L) {
    Mahasiswa* p = L.first;
    while (p != nullptr) {
        cout << "Nama: " << p->nama << ", NIM: " << p->NIM
             << ", Kelas: " << p->kelas << ", Nilai Asesmen: " << p->nilaiAsesmen
             << ", Nilai Praktikum: " << p->nilaiPraktikum << endl;
        p = p->next;
    }
}


void hapusDuplikat(SingleList &L) {
    Mahasiswa* p = L.first;
    while (p != nullptr) {
        Mahasiswa* q = p;
        while (q->next != nullptr) {
            if (q->next->NIM == p->NIM) {
                Mahasiswa* temp = q->next;
                q->next = q->next->next;
                delete temp;
            } else {
                q = q->next;
            }
        }
        p = p->next;
    }
}

int main() {
    SingleList L;
    newList(L);
 
    Mahasiswa* m1 = newElement("Daniel", 2311104063, "A", 85.5, 90.0);
    Mahasiswa* m2 = newElement("Dimas", 2311104069, "B", 88.0, 92.5);
    Mahasiswa* m3 = newElement("Alvin", 2311104070, "A", 85.5, 90.0); 
    
    insertFirst(L, m1);
    insertLast(L, m2);
    insertFirst(L, m3);

    cout << "Sebelum menghapus duplikat:" << endl;
    printList(L);

    hapusDuplikat(L);

    cout << "Setelah menghapus duplikat:" << endl;
    printList(L);

    return 0;
}