#include <iostream>
#include <string>

using namespace std;

struct Mahasiswa {
    string nama;
    int NIM;
    string kelas;
    int nilaiAsesmen;
    int nilaiPraktikum;
};

struct Node {
    Mahasiswa data;
    Node* next;
};

struct SingleLinkedList {
    Node* head;
};

SingleLinkedList newList() {
    SingleLinkedList list;
    list.head = nullptr;
    return list;
}

Node* newElement(Mahasiswa data) {
    Node* newNode = new Node();
    newNode->data = data;
    newNode->next = nullptr;
    return newNode;
}

bool isEmpty(SingleLinkedList list) {
    return list.head == nullptr;
}

void insertFirst(SingleLinkedList &list, Node* newNode) {
    newNode->next = list.head; 
    list.head = newNode; 
}

void printList(SingleLinkedList list) {
    Node* current = list.head;
    while (current != nullptr) {
        cout << "Nama: " << current->data.nama 
             << ", NIM: " << current->data.NIM 
             << ", Kelas: " << current->data.kelas 
             << ", Nilai Asesmen: " << current->data.nilaiAsesmen 
             << ", Nilai Praktikum: " << current->data.nilaiPraktikum << endl;
        current = current->next;
    }
}

Mahasiswa findMaxAsesmen(SingleLinkedList list) {
    Node* current = list.head;
    Mahasiswa maxData = current->data;
    while (current != nullptr) {
        if (current->data.nilaiAsesmen > maxData.nilaiAsesmen) {
            maxData = current->data;
        }
        current = current->next;
    }
    return maxData;
}

void removeDuplicate(SingleLinkedList &list) {
    Node* current = list.head;
    while (current != nullptr) {
        Node* checker = current->next;
        Node* prev = current; 
        while (checker != nullptr) {
            if (checker->data.NIM == current->data.NIM) {
                prev->next = checker->next; 
                delete checker; 
                checker = prev->next; 
            } else {
                prev = checker; 
                checker = checker->next; 
            }
        }
        current = current->next; 
    }
}

int main() {
    cout << "==================================================" << endl;
    cout << "Nama  : Muhammad Daniel Anugrah Pratama" << endl;
    cout << "NIM   : 2311104063" << endl;
    cout << "Kelas : S1SE-07-02" << endl;
    cout << "==================================================" << endl;

    SingleLinkedList list = newList();

    int N;
    cout << "\nMasukkan jumlah mahasiswa: ";
    cin >> N;

    for (int i = 0; i < N; i++) {
        Mahasiswa mhs;
        cout << "Nama: "; cin >> mhs.nama;
        cout << "NIM: "; cin >> mhs.NIM;
        cout << "Kelas: "; cin >> mhs.kelas;
        cout << "Nilai Asesmen: "; cin >> mhs.nilaiAsesmen;
        cout << "Nilai Praktikum: "; cin >> mhs.nilaiPraktikum;

        Node* newNode = newElement(mhs);
        insertFirst(list, newNode); 
    }

    cout << "\nData Mahasiswa:\n";
    printList(list);

    Mahasiswa maxAsesmen = findMaxAsesmen(list);
    cout << "\nMahasiswa dengan nilai asesmen tertinggi:\n";
    cout << "Nama: " << maxAsesmen.nama << ", NIM: " << maxAsesmen.NIM 
         << ", Nilai Asesmen: " << maxAsesmen.nilaiAsesmen << endl;

    removeDuplicate(list);
    cout << "\nData Mahasiswa setelah menghapus duplikat:\n";
    printList(list);

    return 0;
}