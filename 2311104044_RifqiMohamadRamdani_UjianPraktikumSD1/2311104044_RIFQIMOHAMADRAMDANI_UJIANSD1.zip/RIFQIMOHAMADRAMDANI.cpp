#include <iostream>
#include <string>
using namespace std;

struct Mahasiswa {
    string nama;
    string nim;
    string kelas;
    int nilaiAsesmen;
    int nilaiPraktikum;
};

struct ElemenList {
    Mahasiswa info;
    ElemenList* next;
    ElemenList* prev;
};

struct List {
    ElemenList* first;
    ElemenList* last;
};

List createNewList() {
    List l;
    l.first = nullptr;
    l.last = nullptr;
    return l;
}

bool isEmpty(List l) {
    return (l.first == nullptr && l.last == nullptr);
}

ElemenList* newElement(Mahasiswa data) {
    ElemenList* p = new ElemenList;
    p->info = data;
    p->next = nullptr;
    p->prev = nullptr;
    return p;
}

void insertFirst(List &l, ElemenList* p) {
    if (isEmpty(l)) {
        l.first = p;
        l.last = p;
    } else {
        p->next = l.first;
        l.first->prev = p;
        l.first = p;
    }
}

void deleteFirst(List &l) {
    if (!isEmpty(l)) {
        ElemenList* p = l.first;
        if (l.first == l.last) {
            l.first = nullptr;
            l.last = nullptr;
        } else {
            l.first = l.first->next;
            l.first->prev = nullptr;
        }
        delete p;
    }
}

void printList(List l) {
    if (!isEmpty(l)) {
        cout << "Nama: " << l.first->info.nama << ", NIM: " << l.first->info.nim
             << ", Kelas: " << l.first->info.kelas
             << ", Nilai Asesmen: " << l.first->info.nilaiAsesmen
             << ", Nilai Praktikum: " << l.first->info.nilaiPraktikum << endl;
    } else {
        cout << "Daftar kosong!" << endl;
    }
}

int main() {

    List l = createNewList();

    Mahasiswa m1 = {"RIFQI MOHAMAD RAMDANI", "2311104044", "SE0702", 85, 90};

    insertFirst(l, newElement(m1));

    cout << "Isi list setelah penambahan mahasiswa:" << endl;
    printList(l);

    deleteFirst(l);

    cout << "\nIsi list setelah penghapusan mahasiswa:" << endl;
    printList(l);

    return 0;
}
