#include <iostream>
#include <string>

using namespace std;

// Lengkapi Identitas
// Nama  : [Isi dengan nama Anda]
// NIM   : [Isi dengan NIM Anda]
// Kelas : [Isi dengan kelas Anda]

// Struktur data mahasiswa
struct Mahasiswa {
    string nama;
    int nim;
    string kelas;
    float nilaiAsesmen;
    float nilaiPraktikum;
};

// Node untuk Single Linked List
struct Node {
    Mahasiswa data;
    Node* next;
};

// Function untuk membuat node baru
Node* newElement(Mahasiswa m) {
    Node* node = new Node;
    node->data = m;
    node->next = nullptr;
    return node;
}

// Function untuk membuat list baru (kosong)
Node* createNewList() {
    return nullptr;
}

// Procedure untuk mencetak isi list
void printList(Node* head) {
    if (head == nullptr) {
        cout << "List kosong." << endl;
        return;
    }

    Node* temp = head;
    while (temp != nullptr) {
        cout << "Nama: " << temp->data.nama
             << ", NIM: " << temp->data.nim
             << ", Kelas: " << temp->data.kelas
             << ", Nilai Asesmen: " << temp->data.nilaiAsesmen
             << ", Nilai Praktikum: " << temp->data.nilaiPraktikum
             << endl;
        temp = temp->next;
    }
}

// Procedure untuk menambahkan data sesuai mekanisme Insert First dan Insert Last
void addData(Node*& head, Mahasiswa m) {
    Node* newNode = newElement(m);
    if (m.nim % 2 == 1) { // NIM ganjil -> Insert First
        newNode->next = head;
        head = newNode;
    } else { // NIM genap -> Insert Last
        if (head == nullptr) {
            head = newNode;
        } else {
            Node* temp = head;
            while (temp->next != nullptr) {
                temp = temp->next;
            }
            temp->next = newNode;
        }
    }
}

// Procedure untuk mencari mahasiswa dengan nilai asesmen tertinggi
void findHighestAsesmen(Node* head) {
    if (head == nullptr) {
        cout << "List kosong." << endl;
        return;
    }

    Node* temp = head;
    Node* highest = head;

    while (temp != nullptr) {
        if (temp->data.nilaiAsesmen > highest->data.nilaiAsesmen) {
            highest = temp;
        }
        temp = temp->next;
    }

    // Menampilkan mahasiswa dengan nilai asesmen tertinggi
    cout << "Mahasiswa dengan nilai asesmen tertinggi:" << endl;
    cout << "Nama: " << highest->data.nama << endl;
    cout << "NIM: " << highest->data.nim << endl;
    cout << "Kelas: " << highest->data.kelas << endl;
    cout << "Nilai Asesmen: " << highest->data.nilaiAsesmen << endl;
    cout << "Nilai Praktikum: " << highest->data.nilaiPraktikum << endl;
}

// Procedure untuk menghapus data duplikat berdasarkan NIM
void removeDuplicates(Node*& head) {
    if (head == nullptr) return;

    Node* current = head;
    while (current != nullptr) {
        Node* runner = current;
        while (runner->next != nullptr) {
            if (runner->next->data.nim == current->data.nim) {
                Node* duplicate = runner->next;
                runner->next = runner->next->next;
                delete duplicate;
            } else {
                runner = runner->next;
            }
        }
        current = current->next;
    }
}

// Main Program
int main() {
    Node* list = createNewList();

    int N;
    cout << "Masukkan jumlah mahasiswa: ";
    cin >> N;

    for (int i = 0; i < N; i++) {
        Mahasiswa m;
        cout << "Masukkan data mahasiswa ke-" << i + 1 << endl;
        cout << "Nama: ";
        cin >> m.nama;
        cout << "NIM: ";
        cin >> m.nim;
        cout << "Kelas: ";
        cin >> m.kelas;
        cout << "Nilai Asesmen: ";
        cin >> m.nilaiAsesmen;
        cout << "Nilai Praktikum: ";
        cin >> m.nilaiPraktikum;
        addData(list, m);
    }

    cout << "\nData mahasiswa dalam list:" << endl;
    printList(list);

    cout << endl;
    findHighestAsesmen(list);

    cout << "\nMenghapus data duplikat..." << endl;
    removeDuplicates(list);

    cout << "\nData mahasiswa setelah menghapus duplikat:" << endl;
    printList(list);

    return 0;
}
