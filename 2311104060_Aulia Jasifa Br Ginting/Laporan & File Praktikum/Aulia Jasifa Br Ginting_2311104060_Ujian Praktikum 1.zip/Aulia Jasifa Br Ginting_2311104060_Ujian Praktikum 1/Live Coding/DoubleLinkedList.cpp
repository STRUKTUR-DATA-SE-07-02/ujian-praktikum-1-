#include <iostream>
#include <string>

struct Mahasiswa {
    std::string nama;
    std::string nim;
    std::string kelas;
    float nilai_asesmen;
    float nilai_praktikum;
    Mahasiswa* next;
};

class LinkedList {
private:
    Mahasiswa* head;

public:
    LinkedList() : head(nullptr) {}

    void insertLast(std::string nama, std::string nim, std::string kelas, float nilai_asesmen, float nilai_praktikum){
        Mahasiswa* newMahasiswa = new Mahasiswa;
        newMahasiswa->nama = nama;
        newMahasiswa->nim = nim;
        newMahasiswa->kelas = kelas;
        newMahasiswa->nilai_asesmen = nilai_asesmen;
        newMahasiswa->nilai_praktikum = nilai_praktikum;
        newMahasiswa->next = nullptr;

        if (head == nullptr) {
            head = newMahasiswa;
            return;
        }

        Mahasiswa* current = head;
        while (current->next != nullptr) {
            current = current->next;
        }
        current->next = newMahasiswa;

    }

    Mahasiswa* findHighestAesmenscore() {
        if (head == nullptr) {
            return nullptr;
        }

        Mahasiswa* highesScore = head;
        Mahasiswa* current = head->next;

        while (current != nullptr) {
            if (current->nilai_asesmen >highesScore->nilai_asesmen) {
                highesScore = current;
            }
            current = current->next;
        }
        return highesScore;
    }

    void removeDuplicates() {
        if (head == nullptr || head->next == nullptr) {
            return;
        }

        Mahasiswa* current = head;
        while (current->next != nullptr) {
            if (current->next->nim == current->nim) {
                Mahasiswa* temp = current->next;
                current->next = current->next->next;
                delete temp;
            } else {
                current = current->next;
            }
        }
    }

    void printData() {
        Mahasiswa* current = head;
        while (current != nullptr) {
            std:: cout << "Nama: " << current->nama << std::endl;
            std:: cout << "NIM: " << current->nim << std::endl;
            std:: cout << "Kelas: " << current->kelas << std::endl;
            std:: cout << "Nilai Asesmen: " << current->nilai_asesmen << std::endl;
            std:: cout << "Nilai Praktikum: " << current->nilai_praktikum << std::endl;
            std:: cout << std::endl;
            current = current->next;
        }
    }    
};

int main() {
    LinkedList list;


    list.insertLast("John Doe", "123456789", "A", 90.5, 85.0);
    list.insertLast("Jane Smith", "987654321", "B", 92.0, 88.0);
    list.insertLast("Bob Johnson", "123456789", "A", 85.5, 82.0);

    Mahasiswa* highesScore = list.findHighestAesmenscore();
    if (highesScore != nullptr) {
        std::cout << "Mahasiswa dengan nilai tertinggi:" << std::endl;
        std::cout << "Nama:" << highesScore->nama << std::endl;
        std::cout << "NIM:" << highesScore->nim << std::endl;
        std::cout << "Nilai Asesmen:" << highesScore->nilai_asesmen << std::endl;
        std::cout <<  std::endl;
    }
    
    list.removeDuplicates();

    std::cout << "Data Mahasiswa:" << std::endl;
    list.printData();

    return 0;
}

