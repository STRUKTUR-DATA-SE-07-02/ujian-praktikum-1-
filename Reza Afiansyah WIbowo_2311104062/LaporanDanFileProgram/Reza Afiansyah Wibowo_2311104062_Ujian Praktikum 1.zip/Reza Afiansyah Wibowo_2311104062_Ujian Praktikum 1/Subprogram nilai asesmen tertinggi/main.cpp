#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

struct Mahasiswa {
    string nama;
    string nim;
    string kelas;
    float nilaiAsesmen;
    float nilaiPraktikum;
};

struct Node {
    Mahasiswa data;
    Node* next;
    Node* prev;
};

class DoubleLinkedList {
private:
    Node* first;
    Node* last;

public:
    DoubleLinkedList() {
        first = nullptr;
        last = nullptr;
    }

    Node* newElement(Mahasiswa data) {
        Node* newNode = new Node();
        newNode->data = data;
        newNode->next = nullptr;
        newNode->prev = nullptr;
        return newNode;
    }

    bool isEmpty() {
        return first == nullptr;
    }

    void insertFirst(Node* newNode) {
        if (isEmpty()) {
            first = last = newNode;
        } else {
            newNode->next = first;
            first->prev = newNode;
            first = newNode;
        }
    }

    void insertLast(Node* newNode) {
        if (isEmpty()) {
            first = last = newNode;
        } else {
            newNode->prev = last;
            last->next = newNode;
            last = newNode;
        }
    }

    void tambahDataMahasiswa(int N) {
        cin.ignore();

        for (int i = 0; i < N; i++) {
            Mahasiswa mhs;

            cout << "Mahasiswa ke-" << i+1 << ":\n";

            cout << "Nama: ";
            getline(cin, mhs.nama);

            cout << "NIM: ";
            getline(cin, mhs.nim);

            cout << "Kelas: ";
            getline(cin, mhs.kelas);

            cout << "Nilai Asesmen: ";
            cin >> mhs.nilaiAsesmen;

            cout << "Nilai Praktikum: ";
            cin >> mhs.nilaiPraktikum;

            cin.ignore();

            Node* newNode = newElement(mhs);

            int nimAngka = stoi(mhs.nim);
            if (nimAngka % 2 == 1) {
                insertFirst(newNode);
            } else {
                insertLast(newNode);
            }

            cout << endl;
        }
    }

    void tampilkanMahasiswaNilaiTertinggi() {
        if (isEmpty()) {
            cout << "Tidak ada data mahasiswa.\n";
            return;
        }

        Node* current = first;
        Node* mahasiswaTertinggi = first;
        float nilaiTertinggi = first->data.nilaiAsesmen;

        while (current != nullptr) {
            if (current->data.nilaiAsesmen > nilaiTertinggi) {
                nilaiTertinggi = current->data.nilaiAsesmen;
                mahasiswaTertinggi = current;
            }
            current = current->next;
        }

        cout << "=== Mahasiswa dengan Nilai Asesmen Tertinggi ===\n";
        cout << "Nama        : " << mahasiswaTertinggi->data.nama << endl;
        cout << "NIM         : " << mahasiswaTertinggi->data.nim << endl;
        cout << "Kelas       : " << mahasiswaTertinggi->data.kelas << endl;
        cout << "Nilai Asesmen: " << fixed << setprecision(2) << mahasiswaTertinggi->data.nilaiAsesmen << endl;
        cout << "Nilai Praktikum: " << fixed << setprecision(2) << mahasiswaTertinggi->data.nilaiPraktikum << endl;
    }

    void cetakList() {
        if (isEmpty()) {
            cout << "List kosong!\n";
            return;
        }

        cout << "=== Daftar Mahasiswa ===\n";
        Node* current = first;
        int nomor = 1;
        while (current != nullptr) {
            cout << "Mahasiswa " << nomor++ << ":\n";
            cout << "  Nama: " << current->data.nama << endl;
            cout << "  NIM: " << current->data.nim << endl;
            cout << "  Kelas: " << current->data.kelas << endl;
            cout << "  Nilai Asesmen: " << fixed << setprecision(2) << current->data.nilaiAsesmen << endl;
            cout << "  Nilai Praktikum: " << fixed << setprecision(2) << current->data.nilaiPraktikum << endl;
            cout << endl;

            current = current->next;
        }
    }

    ~DoubleLinkedList() {
        while (first != nullptr) {
            Node* temp = first;
            first = first->next;
            delete temp;
        }
    }
};

int main() {
    DoubleLinkedList list;
    int N;

    cout << "Masukkan jumlah mahasiswa: ";
    cin >> N;

    list.tambahDataMahasiswa(N);

    cout << "\n--- Daftar Lengkap Mahasiswa ---\n";
    list.cetakList();

    cout << "\n--- Mahasiswa Nilai Asesmen Tertinggi ---\n";
    list.tampilkanMahasiswaNilaiTertinggi();

    return 0;
}
