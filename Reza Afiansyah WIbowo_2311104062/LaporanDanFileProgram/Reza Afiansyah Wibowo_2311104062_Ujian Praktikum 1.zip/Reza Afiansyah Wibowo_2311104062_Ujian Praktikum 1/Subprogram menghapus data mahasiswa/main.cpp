#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

struct Mahasiswa {
    string nama;
    string nim;
    string kelas;
    float nilaiAsesmen;
    float nilaiPraktikum;
};

struct Node {
    Mahasiswa data;
    Node* next;
    Node* prev;
};

class DoubleLinkedList {
private:
    Node* first;
    Node* last;

public:
    DoubleLinkedList() {
        first = nullptr;
        last = nullptr;
    }

    Node* newElement(Mahasiswa data) {
        Node* newNode = new Node();
        newNode->data = data;
        newNode->next = nullptr;
        newNode->prev = nullptr;
        return newNode;
    }

    bool isEmpty() {
        return first == nullptr;
    }

    void insertFirst(Node* newNode) {
        if (isEmpty()) {
            first = last = newNode;
        } else {
            newNode->next = first;
            first->prev = newNode;
            first = newNode;
        }
    }

    void insertLast(Node* newNode) {
        if (isEmpty()) {
            first = last = newNode;
        } else {
            newNode->prev = last;
            last->next = newNode;
            last = newNode;
        }
    }

    void tambahDataMahasiswa(int N) {
        cin.ignore();

        for (int i = 0; i < N; i++) {
            Mahasiswa mhs;

            cout << "Mahasiswa ke-" << i+1 << ":\n";

            cout << "Nama: ";
            getline(cin, mhs.nama);

            cout << "NIM: ";
            getline(cin, mhs.nim);

            cout << "Kelas: ";
            getline(cin, mhs.kelas);

            cout << "Nilai Asesmen: ";
            cin >> mhs.nilaiAsesmen;

            cout << "Nilai Praktikum: ";
            cin >> mhs.nilaiPraktikum;

            cin.ignore();

            Node* newNode = newElement(mhs);

            int nimAngka = stoi(mhs.nim);
            if (nimAngka % 2 == 1) {
                insertFirst(newNode);
            } else {
                insertLast(newNode);
            }

            cout << endl;
        }
    }

    void hapusDataDuplikat() {
        if (isEmpty() || first == last) {
            cout << "Tidak ada data duplikat untuk dihapus.\n";
            return;
        }

        int jmlDihapus = 0;

        Node* current = first;

        while (current != nullptr) {
            Node* pembanding = current->next;
            Node* prevPembanding = current;

            while (pembanding != nullptr) {
                if (current->data.nim == pembanding->data.nim) {
                    if (pembanding->prev) {
                        pembanding->prev->next = pembanding->next;
                    }
                    if (pembanding->next) {
                        pembanding->next->prev = pembanding->prev;
                    }

                    if (pembanding == first) {
                        first = pembanding->next;
                    }
                    if (pembanding == last) {
                        last = pembanding->prev;
                    }

                    Node* hapus = pembanding;

                    pembanding = pembanding->next;

                    delete hapus;

                    jmlDihapus++;
                } else {
                    pembanding = pembanding->next;
                }
            }

            current = current->next;
        }

        if (jmlDihapus > 0) {
            cout << "Sejumlah " << jmlDihapus << " data mahasiswa duplikat telah dihapus.\n";
        } else {
            cout << "Tidak ada data mahasiswa duplikat yang ditemukan.\n";
        }
    }

    void cetakList() {
        if (isEmpty()) {
            cout << "List kosong!\n";
            return;
        }

        cout << "=== Daftar Mahasiswa ===\n";
        Node* current = first;
        int nomor = 1;
        while (current != nullptr) {
            cout << "Mahasiswa " << nomor++ << ":\n";
            cout << "  Nama: " << current->data.nama << endl;
            cout << "  NIM: " << current->data.nim << endl;
            cout << "  Kelas: " << current->data.kelas << endl;
            cout << "  Nilai Asesmen: " << fixed << setprecision(2) << current->data.nilaiAsesmen << endl;
            cout << "  Nilai Praktikum: " << fixed << setprecision(2) << current->data.nilaiPraktikum << endl;
            cout << endl;

            current = current->next;
        }
    }

    ~DoubleLinkedList() {
        while (first != nullptr) {
            Node* temp = first;
            first = first->next;
            delete temp;
        }
    }
};

int main() {
    DoubleLinkedList list;
    int N;

    cout << "Masukkan jumlah mahasiswa: ";
    cin >> N;

    list.tambahDataMahasiswa(N);

    cout << "\n--- Daftar Lengkap Mahasiswa Sebelum Hapus Duplikat ---\n";
    list.cetakList();

    cout << "\n--- Proses Hapus Data Duplikat ---\n";
    list.hapusDataDuplikat();

    cout << "\n--- Daftar Lengkap Mahasiswa Setelah Hapus Duplikat ---\n";
    list.cetakList();

    return 0;
}
