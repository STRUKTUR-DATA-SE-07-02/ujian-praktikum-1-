#include <iostream>
using namespace std;

struct Node{
    int data;
    Node* next;
};

Node* newElement(int data){
    Node* newNode = new Node();
    newNode->data = data;
    newNode->next = nullptr;
    return newNode;
}

Node* createNewList(){
    return nullptr;
}

bool isEmpty(Node* head){
    return head == nullptr;
}

void insertFirst(Node*& head, Node* newNode){
    newNode->next = head;
    head = newNode;
}

void insertAfter(Node* head, int x, Node* newNode){
    Node* current = head;
    while (current != nullptr && current->data != x){
        current = current->next;
    }
    if (current != nullptr){
        newNode->next = current->next;
        current->next = newNode;
    }
}

void insertLast(Node*& head, Node* newNode){
    if (isEmpty(head)){
        head = newNode;
    } else {
        Node* current = head;
        while ( current->next != nullptr){
            current = current->next;
        }
        current->next = newNode;
    }
}

void deleteFirst(Node*& head){
    if(!isEmpty(head)) {
        Node* temp = head;
        head = head->next;
        delete temp;
    }
}

void deleteLast(Node*& head) {
    if (!isEmpty(head)) {
        if (head->next == nullptr) {
            delete head;
            head = nullptr;
        } else {
            Node* current = head;
            while(current->next->next != nullptr) {
                current = current->next;
            }
            delete current->next;
            current->next = nullptr;
        }
    }
}

int length(Node* head){
    int count = 0;
    Node* current = head;
    while (current != nullptr){
        count++;
        current = current->next;
    }
    return count;
}

Node* findElement(Node* head, int x){
    Node* current = head;
    while (current != nullptr && current->data != x){
        current = current->next;
    }
    return current;
}

void printList(Node* head){
    Node* current = head;
    while (current != nullptr){
        cout << current->data << "->";
        current = current ->next;
    }
    cout << "NULL" << endl;
}

int main() {
    Node* list = createNewList();

    insertFirst(list, newElement(10));
    insertFirst(list, newElement(20));
    insertLast(list, newElement(30));
    insertAfter(list, 20, newElement(25));

    cout << "Isi List: ";
    printList(list);

    cout << "Panjang list: " << length(list) << endl;

    Node* found = findElement(list, 25);
    if (found != nullptr){
        cout << "Element 25 ditemukan." << endl;
    }

    deleteFirst(list);
    deleteLast(list);

    cout << "Isi list setelah penghapusan: ";
    printList(list);

    return 0;

}